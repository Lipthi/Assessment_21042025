let flattenAndSort(){
    arr = [[3,2,1],[4,5,2],[1,6]];
    let flatArray = arr.flatten(Infinity);
    for(i = 0;i<n;i++){
        for(j = i+1;j<n;j++){
            if(i>j){
                j=i;
            }
        }
}
}
flattenAndSort(arr)