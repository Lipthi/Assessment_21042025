function countVowels(str){
    let vowels = [a,e,i,o,u];
    let str = 'Hello world';
    for(val in vowels){
        if(str.split() == vowels)
            
    }

}